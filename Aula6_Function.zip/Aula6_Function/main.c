#include <stdio.h>
#include <stdlib.h>
#include <windows.h>    // Para usar a funcao Sleep(1000)

struct xapa{
    int S1;
    int S2;
};

struct xupa {
    int M1;
    int M2;
};

struct xapa LeSensors(void);

struct xupa IA(int ss1, int ss2);

void DriveMotors(int mmm1, int mmm2);

int main()
{
    int s1, s2, m1, m2;
    struct xapa llleituras;
    struct xupa mmmotors;

    while(1)
    {
        llleituras = LeSensors();
        s1 = llleituras.S1;
        s2 = llleituras.S2;

        mmmotors = IA(s1, s2);
        m1 = mmmotors.M1;
        m2 = mmmotors.M2;

        DriveMotors(m1, m2);
    }
    return 0;   //Retorna 0 para dizer que deu tudo certo!
}

struct xapa LeSensors(void) {
    int distancia1, distancia2, leitura1, leitura2;
    scanf("%d %d", &distancia1, &distancia2);
    if(distancia1 < 50)
        leitura1 = 1;
    else
        leitura1 = 0;

    if(distancia2 < 50)
        leitura2 = 1;
    else
        leitura2 = 0;

    //return leitura1, leitura2;
    // --> Nao pode retornar dois valores!!

    struct xapa leituras;
    leituras.S1 = leitura1;
    leituras.S2 = leitura2;

    return leituras;    // Pode retornar 1 struct com varios valores
}

struct xupa IA(int ss1, int ss2) {

    int mm1, mm2;
    if(ss1==0 && ss2==0)      {mm1=1; mm2=1;}
    else if(ss1==1 && ss2==0) {mm1=1; mm2=0;}
    else if(ss1==0 && ss2==1) {mm1=0; mm2=1;}
    else if(ss1==1 && ss2==1) {mm1=0; mm2=1;}

    struct xupa motors;
    motors.M1 = mm1;
    motors.M2 = mm2;

    return motors;
}

void DriveMotors(int mmm1, int mmm2)    {

    printf("    M1=%d M2=%d\n", mmm1, mmm2);
    //return 0; // como e' void nao precisa retornar!!
}



/*

// Variaveis Globais

int S1, S2, M1, M2;

void LeSensors(void);

void IA(void);

void DriveMotors(void);

int main()
{
    while(1){
       LeSensors() ;
       IA();
       DriveMotors();
    }
    return 0;
}

void LeSensors(void) {
    int distancia1, distancia2;
    scanf("%d %d", &distancia1, &distancia2 ....)

    if(distancia1 < 50)
        S1 = 1;  // Global!!!!
    else
        S1 = 0;

    if(distancia2 < 50)
        S2 = 1;  // Global!!!!
    else
        S2 = 0;

    return;
}


void IA(void) {

    if(ljkgljgljgljglhvgljgvljhvlj)

    return ;
}

void DriveMotors(void)    {

    printiefa M1 e M2.....

    return;
}

*/
