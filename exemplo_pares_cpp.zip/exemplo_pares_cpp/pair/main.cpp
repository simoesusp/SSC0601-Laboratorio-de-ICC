#include <iostream>

std::pair<int, double> atribuirPar(int primeiro, double segundo){
    std::pair<int, double> par;
    par.first = primeiro;
    par.second = segundo;
    return par;
}

int main(){
    std::pair<int, double> meuPar;
    meuPar = atribuirPar(10, 0.872839);


    std::cout << "Primeiro:  " << meuPar.first <<std::endl;
    std::cout << "Segundo:   " << meuPar.second <<std::endl;
    return 0;
}
