// Programa para Testar a Tela Grafica (Graphics.h - BGI)


//Funcoes Uteis:
//      void line (int x1, int y1, int x2, int y2);
//
//      void linerel (int dx, int dy);
//
//      void lineto (int x, int y);
//
//      void outtext (char *textstring);
//
//      void outtextxy (int x, int y, char *textstring);
//
//      void pieslice (int x, int y, int stangle, int endangle, int radius);
//
//      void putpixel (int x, int y, int color);
//
//      void rectangle (int left, int top, int right, int bottom);
//
//      setcolor(BLUE);             // Change drawing color to BLUE.
//      setcolor(COLOR(255,100,0)); // Change drawing color to reddish-green.
//      void setbkcolor (int color);
//      int getmaxy(void);

//Colores: Name	Value
        //BLACK 	0
        //BLUE	1
        //GREEN	2
        //CYAN	3
        //RED	4
        //MAGENTA	5
        //BROWN	6
        //LIGHTGRAY	7
        //DARKGRAY	8
        //LIGHTBLUE	9
        //LIGHTGREEN	10
        //LIGHTCYAN	11
        //LIGHTRED	12
        //LIGHTMAGENTA	13
        //YELLOW	14
        //WHITE	15




#include <stdio.h>  // Printf
#include <graphics.h>

  int main()
  {
    int key;    // Le Teclado
	int x = 1, y = 1;   // Coord. Nave

// Liga Tela Grafica
    initwindow(800,600); //open a 400x300 graphics window

    outtextxy(30,20, "Tela Grafica !!");  // Escreve na tela

    rectangle(30,20, 120,35);

    moveto(0,0);    // Teste Tela Grafica!
    lineto(50,50);

    const char* title="cara.bmp";
    readimagefile(title, 60,60,200,600);  // Com NULL abre menuzinho!

loop:

    if (kbhit());
        key = getch();

	if (key == KEY_LEFT)
		x--;
	if (key == KEY_RIGHT)
		x++;
	if (key == KEY_UP)
		y--;
	if (key == KEY_DOWN)
		y++;
	if (key == 'q')
		goto fim;

// Condicoes de contorno da Nave em funcao das variaveis de tamanho da tela
    if (y == -1)
        y = getmaxy()-1;
    if (y == getmaxy())
        y = 0;
    if (x == -1)
        x = getmaxx()-1;
    if (x == getmaxx())
        x = 0;


// Teste Grafico
//    setcolor(COLOR(255,100,0));  // Pode-se trocar diretamente a cor no RGB !!
//    lineto(x,y);
    putpixel(x,y,12);  // Color = Light Magenta


    goto loop;

fim:
    closegraph();        //close graphics window

    return 0;
  }
