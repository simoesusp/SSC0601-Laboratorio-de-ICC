// Programa para Testar 2 ambientes silmultaneos:
// Tela Grafica (Graphics.h - BGI)
// Funcoes do Windows (Windows.h)


// A T E N C A O !

        // Para funcionar a Windows.h,
        // Tem que incluir no Project / Build Options / Linker Settings: Winmm

        // Pra funcionar a Graphics.h
        // Tem que comecar o projeto como C++
        // Project / Build Options / Linker Settings:
                //bgi
                //gdi32
                //comdlg32
                //uuid
                //oleaut32
                //ole32

#define WINDOWX 800
#define WINDOWY 600

#include <graphics.h>
#include <stdio.h>  // Printf
#include <windows.h>  // Inclua a biblioteca Windows.h para usar o SOM
                      // Inclua no projeto a DLL :  Winmm


  int main()
  {
    int key, lastkey;    // Le Teclado
	int x = 1, y = 1;   // Coord. Nave
	int velhox = 1, velhoy = 1;   // Coord. Velhas da Nave
	char *imagem1, *imagem2;    // Pointer para Figuras

// Liga Tela Grafica
    initwindow(WINDOWX,WINDOWY); //open a 400x300 graphics window


// Le imagem do arquivo
    readimagefile("cara.bmp", 0,0,500,500);  // Com NULL abre menuzinho!
// Reserva memoria para a imagem
    imagem2=(char *)malloc(imagesize(0,0,500,500));
// Salva imagem na memoria
    getimage(0,0,500,500,imagem2);


// Carrega imagem do Mario na memoria
    readimagefile("mario2.jpg",0,0,30,30);
    imagem1=(char *)malloc(imagesize(0,0,30,30));
    getimage(0,0,30,30,imagem1);


// Toca SOM.wav   INCLUDE WINDOWS.H
    PlaySound("tada.wav", NULL, SND_ASYNC);   // PlaySound(NULL, 0, 0); --> Para um som tocando assincronamente
                            // SND_SYNC  -> Fica tocando ate' terminar e sai da funcao


loop:
    key = 'a';
    while(kbhit())
        key = getch();


    if(key != 'a')
        {
        if (key == KEY_LEFT)
            x--;
        if (key == KEY_RIGHT)
            x++;
        if (key == KEY_UP)
            y--;
        if (key == KEY_DOWN)
            y++;
        if (key == 'q')
            goto fim;
        if (key == 'x')
        {setbkcolor(WHITE); cleardevice();}
        if (key == 'z')
            swapbuffers();
        if (key == '1')
            {setactivepage(0); setvisualpage(0);}
        if (key == '2')
            {setactivepage(1); setvisualpage(1);}

    // Condicoes de contorno da Nave em funcao das variaveis de tamanho da tela
        if (y == -1)
            y = WINDOWY-1;
        if (y == WINDOWY)
            y = 0;
        if (x == -1)
            x = WINDOWX-1;
        if (x ==WINDOWX)
            x = 0;

        }

    if ((x!=velhox)or(y!=velhoy))   // Se as coordenadas da nave mudaram, redezenha!!
        {
        //putimage(velhox,velhoy,imagem1,XOR_PUT); // Apaga Mario

        velhox=x;   // Atualiza coordenadas
        velhoy=y;

        putimage(0,0,imagem2,COPY_PUT);  // Desenha Fundo, apagando o Mario
        putimage(x,y,imagem1,COPY_PUT); // Desenha Mario COPY_PUT
        swapbuffers(); // Troca os buffers de tela para escrever em um e mostrar o outro
        }

    //swapbuffers(); // Troca os buffers de tela para escrever em um e mostrar o outro

    //delay(50);

    goto loop;

fim:

    closegraph();        //close graphics window

    return 0;
  }
