// Programa para Testar um AG
// O AG tende a convergir para os otimos locais da funcao!
// Com predacao SEMPRE encontra o Otimo Global !!!

// A T E N C A O !
        // Pra funcionar o Graphics.h
        // Tem que comecar o projeto como C++
        // Tem que incluir no Project -> Build Options -> Linker Settings:
                // bgi
                // gdi32
                // comdlg32
                // uuid
                // oleaut32
                // ole32

//Funcoes principais da Graphics.h:
//      void line (int x1, int y1, int x2, int y2);
//
//      void linerel (int dx, int dy);
//
//      void lineto (int x, int y);
//
//      void outtext (char *textstring);
//
//      void outtextxy (int x, int y, char *textstring);
//
//      void pieslice (int x, int y, int stangle, int endangle, int radius);
//
//      void putpixel (int x, int y, int color);
//
//      void rectangle (int left, int top, int right, int bottom);
//
//      setcolor(BLUE);             // Change drawing color to BLUE.
//      setcolor(COLOR(255,100,0)); // Change drawing color to reddish-green.
//      void setbkcolor (int color);

//Color Name	Value
    //BLACK 	0
    //BLUE	1
    //GREEN	2
    //CYAN	3
    //RED	4
    //MAGENTA	5
    //BROWN	6
    //LIGHTGRAY	7
    //DARKGRAY	8
    //LIGHTBLUE	9
    //LIGHTGREEN	10
    //LIGHTCYAN	11
    //LIGHTRED	12
    //LIGHTMAGENTA	13
    //YELLOW	14
    //WHITE	15






#define TamPop 10
#define TaxMut 10   // 10 = 10%
#define maxx 40
#define zoomx 1.0
#define zoomy 10.0

#include <graphics.h>
#include <stdio.h>  // Printf, sprintf
#include <stdlib.h> // Rand
#include <math.h>
#include <time.h>  // Inicializa a Semente do Rand


// Variaveis Globais
double ind[TamPop + 1];  // Contem os cromossomos dos individuos
double fit[TamPop + 1];  // Vetor para guardar a pontuacao dos individuos
double maxfit = 0.0;
int    maxi  = 0;
double media = 0.0;
int    w = 0;
int    i, g = 0;
int    key, show, step, passa;  // Controle de execussao
char   msg[100];

// Funcoes
void initpop()
{
    for (i=1;i<=TamPop;i++)
    {                         // nr entre -10 e +10 -> rand() %20 - 10;
        ind[i] = (double) (rand() %(maxx * 10)/10.0);
    }
}

void avalia()
{
    // Funcao Senoidal com varios otimos locais
    double x;
    for (i=1;i<=TamPop;i++)
    {
        x=ind[i];
        fit[i] = 2*cos(0.39*x) + 5*sin(0.5*x) + 0.5*cos(0.1*x)
         + 10*sin(0.7*x) + 5*sin(1*x) + 5*sin(0.35*x);
    }

  /*  //Funcao Sobe e Desce
  for (i=1;i<=TamPop;i++)
    {
        x=ind[i];
        if (x>=0.0 and x<10.0)
            fit[i] = x;
        else if (x>=10.0 and x<20.0)
            fit[i] = 20.0 - x;
        else
            fit[i] = 0.0;
    }*/
}

void elitismo() // Melhor transa com todos
{
    maxfit = fit[1];
    maxi   = 1;
    for (i=2;i<=TamPop;i++)  // Busca pelo melhor individuo
    {
        if (fit[i]>maxfit)
        {
            maxfit = fit[i];
            maxi = i;   // Quando terminar, maxi tem o i do melhor individuo
        }
    }

    for (i=1;i<=TamPop;i++)
    {
        if (i==maxi)        // Protege o melhor individuo
            continue;

        // Crossover
        ind[i] = (ind[i] + ind[maxi])/ 2.0;

        // Mutacao                    | nr = 0-40 |    - 20    |  0,02  |  10%
        ind[i] = ind[i] + (double)
        (((rand() %maxx - (maxx/2.0))/100.0) * TaxMut);
    }
}

void torneio()  // Torneio de Dois
{
    int a, b, pai1, pai2;
    double indaux[TamPop + 1];  // Vetor auxiliar para o torneio

    maxfit = fit[1];
    maxi   = 1;
    for (i=2;i<=TamPop;i++)    // Busca pelo melhor individuo para protege-lo
    {
        if (fit[i]>maxfit)
        {
            maxfit = fit[i];
            maxi = i;  // Quando terminar, maxi tem o i do melhor individuo
        }
    }

    for (i=1;i<=TamPop;i++)
    {
        if (i==maxi)    // Protege o melhor individuo
            {indaux[i] = ind[i];
             continue;
            }

        // Sorteia dois individuos para 1ro torneio
        a = (rand() %TamPop) + 1;
        b = (rand() %TamPop) + 1;
        if (fit[a] > fit[b])
            pai1 = a;
        else
            pai1 = b;

        // Sorteia mais dois individuos para 2do torneio
        a = (rand() %TamPop) + 1;
        b = (rand() %TamPop) + 1;
        if (fit[a] > fit[b])
            pai2 = a;
        else
            pai2 = b;

        // Crossover
        indaux[i] = (ind[pai1] + ind[pai2])/ 2.0;

        // Mutacao                    | nr = 0-40 |    - 20    |  0,02  |  10%
        indaux[i] = indaux[i] + (double) (((rand() %maxx - (maxx/2.0))/100.0) * TaxMut);
    }
    // Copia o Vetor auxiliar para o vetor dos individuos ind[]
    for (i=1;i<=TamPop;i++)
        ind[i] =indaux[i];
}


void torneion(int n)  // Torneio de n individuos
{
    int j, pai1, pai2;
    int indice[n + 1];
    int maxj;
    double maxfitj;
    double indaux[TamPop + 1];  // Vetor auxiliar para o torneio

    maxfit = fit[1];
    maxi   = 1;
    for (i=2;i<=TamPop;i++)    // Busca pelo melhor individuo para protege-lo
    {
        if (fit[i]>maxfit)
        {
            maxfit = fit[i];
            maxi = i;  // Quando terminar, maxi tem o i do melhor individuo
        }
    }

    // Comecam a producao de filhos por Torneio
    for (i=1;i<=TamPop;i++)
    {
        if (i==maxi)    // Protege o melhor individuo
            {indaux[i] = ind[i];
             continue;
            }
        else
            {

            // Sorteia n individuos para 1ro torneio
            for (j=1;j<=n;j++)
                indice[j] = (rand() %TamPop) + 1;

            maxfitj = fit[indice[1]];
            maxj   = indice[1];
            for (j=2;j<=n;j++)    // Busca pelo melhor individuo do torneio
                {
                    if (fit[indice[j]]>maxfitj)
                    {
                        maxfitj = fit[indice[j]];
                        maxj = indice[j];
                    }
                }
            pai1 = maxj;

            // Sorteia n individuos para 2o torneio
            for (j=1;j<=n;j++)
                indice[j] = (rand() %TamPop) + 1;

            maxfitj = fit[indice[1]];
            maxj   = indice[1];
            for (j=2;j<=n;j++)    // Busca pelo melhor individuo do torneio
                {
                    if (fit[indice[j]]>maxfitj)
                    {
                        maxfitj = fit[indice[j]];
                        maxj = indice[j];
                    }
                }
            pai2 = maxj;

            // Crossover
            indaux[i] = (ind[pai1] + ind[pai2])/ 2.0;

            // Mutacao                    | nr = 0-40 |    - 20    |  0,02  |  10%
            indaux[i] = indaux[i] + (double) (((rand() %maxx - (maxx/2.0))/100.0) * TaxMut);
            }
    }
    // Copia o Vetor auxiliar para o vetor dos individuos ind[]
    for (i=1;i<=TamPop;i++)
        ind[i] =indaux[i];
}

void predacao() // Mata o Pior individo e substitui por um Randomico
{
    double minfit = fit[1];
    int    mini   = 1;
    for (i=2;i<=TamPop;i++)  // Busca pelo pior individuo
    {
        if (fit[i]<minfit)
        {
            minfit = fit[i];
            mini = i;  // Quando terminar, mini tem o i do pior individuo
        }
    }
    // Mata o Pior e troca por um Randomico
    ind[mini] = (double) (rand() %(maxx * 10)/10.0);
}

// Funcao que desenha o grafico da Funcao Objetivo
void drawfunction() // Warning: - Nao tente entender!!!
{
    double x,y;
    int j,k;

    setcolor(YELLOW);
    line(0,300,800,300);    // Eixo X
    for (j=0;j<=800;j++)
    {
        x = zoomx * (j * (double)(maxx/800.0));   // Divide maxX em 800 pontos

        y = 2*cos(0.39*x) + 5*sin(0.5*x) + 0.5*cos(0.1*x) + 10*sin(0.7*x) + 5*sin(1*x) + 5*sin(0.35*x);  // Calcula a F(x) normalmente

        k = (int) (300 - y * zoomy);   // Inverte o Eixo Y e faz k=300 quando Y=0

        putpixel(j,k,14);  // Color = Light red
    }

}

  int main()
  {
// Liga Tela Grafica
   {
    initwindow(800,600);                    //open a 800x600 graphics window
    setactivepage(1); setvisualpage(1);     // Liga a Tela 1! A graphics tem 2 Telas!!
    setcolor(WHITE);                          // Define a cor
    setbkcolor(BLACK);    // Seleciona cor de fundo da tela: preta
    cleardevice();        // Limpa tela (deixa toda tela preta)

    outtextxy(1,1, "Type q -> quit;  x -> pause;  p -> step;  i -> reinitialize Evolution;  h -> show/hide");

    srand(time(NULL));  // generate the seed for randomness
    }

    drawfunction();  // Desenha grafico da funcao




inicio:     // Reinicializa Variaveis de controle, Geracao e Populacao
    g = 0;  // Geracoes

    // Variaveis de Controle de Execussao (Flags)
    {
    show = 'a';     // Mostra Geracoes e Individuos e Grafico
    step = 'x';     // Execussao Passo a Passo
    passa = 'a';    // Pula de geracao em geracao: a = Nao Pula!!
    }


    initpop();      // Inicializa Populacao



loop:               // Loop Principal
    g++;            // incrementa contador de geracao

    avalia();       // Avalia os individuos da Populacao

    elitismo();    // Seleciona o melhor individuo para transar com todos e Faz Crossover e Mutacao e ja' substitui na Populacao

    //torneio();    // FAz torneio de 2 entre os individuos, e Faz Crossover e Mutacao e ja' substitui na Populacao

    //torneion(4);    // FAz torneio de n entre os individuos, e Faz Crossover e Mutacao e ja' substitui na Populacao

    if(( g % 10 ) == 0) predacao();  // Chama predacao a cada 10 geracoes



    // Final do Algoritmo Evolutivo
//------------x---------------x------------



    // Inicio da parte grafica

    if (show == 'a')    // Se quizer ver a evolucao dos individuos passo a passo -> Fica mais lento!
    {
        media = 0.0;    // Calcula a Media do Fitness da Populacao
        for (i=1;i<=TamPop;i++)
            media = media + fit[i];
        media = media / TamPop;

        // Gera string para imprimir na tela grafica!
        setcolor(WHITE);
        sprintf(msg,"Ger = %08d  Melhor = %2d  Fitness Melhor = %3.6f  Media Fitness = %f  TaxMut = %d ", g, maxi, fit[maxi], media, TaxMut);
        outtextxy(1,20,msg);

        setcolor(BLUE);    // Risca eixo X para apagar risquinhos dos individuos
        line(0,300,800,300);

        setcolor(GREEN);    // Marca a pos X de cada individuo no grafico
        for (i=1;i<=TamPop;i++)
        {
            w = (int)(ind[i] / (zoomx * (double)(maxx/800.0)));  // Conversao para a tela: Quando X = 40, w = 800
            line(w,297,w,303);      // Risca cada individuo

        }


        // Risca de Branco o melhor individuo !!
        w = (int)(ind[maxi] / (zoomx * (double)(maxx/800.0)));
        setcolor(WHITE);
        line(w,297,w,303);      // Risca

    }

letecla:
    if (kbhit())    // So' faz as comparacoes de teclas se uma tecla for realmente precionada para ganhar tempo
	{

        key = getch();
        if (key == 'p')     // Exibicao passo a passo: p = passa uma geracao pra frente
            passa = 'p';
        if (key == 'q')
            goto fim;       // q = sai fora do loop
        if (key == 'i')     // i = reinicializa o processo evolutivo e a Populacao
            {
                setcolor(BLACK);    // Mas antes apaga os risquinhos dos individuos no grafico!!
                for (i=1;i<=TamPop;i++)
                {
                    w = (int)(ind[i] / (zoomx * (double)(maxx/800.0)));
                    line(w,297,w,303);

                }
                goto inicio;        // Depois de apagar... Reinicializa!!
            }

        if (key == 'h')     // h = Esconde a saida de tela para Evoluir muito mais rapido!
            if(show == 'a')
                show = 'h';
            else
                show = 'a';

        if (key == 'x')    // x = trava a evolucao!  a = solta o processo!
            if(step == 'a')
                step = 'x';
            else
                step = 'a';

	}   // Fim do menu de Teclado do Kbhit



    // Controle Passo a passo
    {
    if (step == 'x' && passa == 'a')
        goto letecla;   // Congela a evolucao
    else if (step == 'x' && passa == 'p')   // Passo a passo
        passa = 'a';
    }

    if (show == 'a')    // Apaga todos os risquinhos dos individuos antes de voltar pro Loop!
    {                   // So' apaga se estiver mostrando, para nao perder tempo quando em background!!
        setcolor(BLACK);
        for (i=1;i<=TamPop;i++)
        {
            w = (int)(ind[i] / (zoomx * (double)(maxx/800.0)));
            line(w,297,w,303);
        }
    }



    goto loop;      // Volta pro Loop principal



fim:
    closegraph();        //close graphics window

    return 0;
  }
