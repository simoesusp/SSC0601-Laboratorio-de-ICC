#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <windows.h>

#define VEL_MAX 2
#define PACE 0.125

typedef struct Motor{
    float vel;
}_Motor;
typedef struct Sensor{
    float distance;
}_Sensor;



void printVelMot(_Motor Dir, _Motor Esq);
void printSensors(_Sensor Dir, _Sensor Cen, _Sensor Esq);

void printGraph(_Motor mDir, _Motor mEsq, _Sensor sDir, _Sensor sCen, _Sensor sEsq);


int main(){

    char status = 'n', hit = 0;
    _Motor motorDireito, motorEsquerdo;
    _Sensor sensorDireito, sensorEsquerdo, sensorCentral;
    motorDireito.vel=motorEsquerdo.vel=0;
    sensorDireito.distance=sensorCentral.distance=sensorEsquerdo.distance=5.0;

    while(status != 'o'){
            if(_kbhit()){
                    status = hit = _getch();
                    switch(hit){
                        case 'q':
                            sensorEsquerdo.distance+=PACE;
                            break;
                        case 'a':
                            sensorEsquerdo.distance-=PACE;
                            if(sensorEsquerdo.distance<0){sensorEsquerdo.distance=0.0;};
                            break;
                        case 'e':
                            sensorCentral.distance+=PACE;
                            break;
                        case 'd':
                            sensorCentral.distance-=PACE;
                            if(sensorCentral.distance<0){sensorCentral.distance=0.0;}
                            break;
                        case 't':
                            sensorDireito.distance+=PACE;
                            break;
                        case 'g':
                            sensorDireito.distance-=PACE;
                            if(sensorDireito.distance<0){sensorDireito.distance=0.0;}
                            break;
                        default:
                            break;
                    }
            }


        motorDireito.vel=motorEsquerdo.vel=VEL_MAX;

        if(sensorDireito.distance<=1.5){
            motorDireito.vel = VEL_MAX/2;
            motorEsquerdo.vel = 0;
        }
        if(sensorEsquerdo.distance<=1.5){
            motorDireito.vel=0;
            motorEsquerdo.vel=VEL_MAX/2;
        }

        if(sensorCentral.distance <= 1.0 ){
            motorDireito.vel = -VEL_MAX;
            motorEsquerdo.vel = VEL_MAX;
        }

        system("cls");
        printGraph(motorDireito, motorEsquerdo, sensorDireito, sensorCentral, sensorEsquerdo);
        Sleep(170);
    }
    system("cls");
    motorEsquerdo.vel =0;
    motorDireito.vel =0;
    printVelMot(motorDireito, motorEsquerdo);
    printf("\nPrograma Encerrado.\n\n");

    return 0;

}

void printVelMot(_Motor Dir, _Motor Esq){
    printf("\n\n                          Motor Direito:   %.2f \n\n                          Motor Esquerdo:  %.2f\n", Dir.vel, Esq.vel);
    }

void printSensors(_Sensor Dir, _Sensor Cen, _Sensor Esq){
     if(Esq.distance>=5.0){printf("\nDistancia a esquerda: 5+\n");} else{printf("\nDistancia a esquerda: %.3f\n", Esq.distance);}
     if(Cen.distance>=5.0){printf("Distancia no centro:  5+\n");} else{printf("Distancia no centro:  %.3f\n", Cen.distance);}
     if(Dir.distance>=5.0){printf("Distancia a direita:  5+\n");} else{printf("Distancia a direita:  %.3f\n", Dir.distance);}
}


void printGraph(_Motor mDir, _Motor mEsq, _Sensor sDir, _Sensor sCen, _Sensor sEsq){
    int i, j;
    char se[10], sc[10], sd[10], md[10], me[10];
    for(i=0;i<10;i++){se[i]=sc[i]=sd[i]=md[i]=me[i]=' ';}

    for(i=2; i<=10; i++){
        if(sEsq.distance<=i/2){
            se[10-i] = 177;
        }
        if(sCen.distance<=i/2){
            sc[10-i] = 177;
        }
        if(sDir.distance<=i/2){
            sd[10-i] = 177;
        }
    }
    if(sEsq.distance<=0.5){
        se[9] = 178;
    }
    if(sCen.distance<=0.5){
        sc[9] = 178;
    }
    if(sDir.distance<=0.5){
        sd[9] = 178;
    }
    for(j=5; j>=1;j--){
        if(mDir.vel>=(VEL_MAX*j)/5.0){
            for(i=9; i>=5;i--){
                md[i]=176;
            }
            for(i=4;i>=0;i--){
                md[i]=' ';
            }
        }
    }
    for(j=1; j<=5;j++){
        if(mDir.vel<=(-VEL_MAX*j)/5.0){
            for(i=9;i>=5;i--){
                md[i]=' ';
            }
            for(i=4; i>=0;i--){
                md[i]=176;
            }
        }
    }


    for(j=5; j>=1;j--){
        if(mEsq.vel>=(VEL_MAX*j)/5.0){
            for(i=9; i>=5;i--){
                me[i]=176;
            }
            for(i=4;i>=0;i--){
                me[i]=' ';
            }
        }
    }




    printf("\n");
    printf("     Sensor Esquerdo          Sensor  Central          Sensor  Direito \n\n");
    printf("    0m ||%c%c%c%c%c%c%c||           0m ||%c%c%c%c%c%c%c||           0m ||%c%c%c%c%c%c%c||\n", se[9], se[9], se[9], se[9], se[9], se[9], se[9], sc[9], sc[9], sc[9], sc[9], sc[9], sc[9], sc[9], sd[9], sd[9], sd[9], sd[9], sd[9], sd[9], sd[9]);
    for(i=8; i>0; i--){
        printf("       ||%c%c%c%c%c%c%c||              ||%c%c%c%c%c%c%c||              ||%c%c%c%c%c%c%c||\n", se[i], se[i], se[i], se[i], se[i], se[i], se[i], sc[i], sc[i], sc[i], sc[i], sc[i], sc[i], sc[i], sd[i], sd[i], sd[i], sd[i], sd[i], sd[i], sd[i]);
    }
    printf("    5m ||%c%c%c%c%c%c%c||           5m ||%c%c%c%c%c%c%c||           5m ||%c%c%c%c%c%c%c||\n", se[0], se[0], se[0], se[0], se[0], se[0], se[0], sc[0], sc[0], sc[0], sc[0], sc[0], sc[0], sc[0], sd[0], sd[0], sd[0], sd[0], sd[0], sd[0], sd[0]);

    printf("\n                  Motor Esquerdo           Motor  Direito \n\n");
    printf("                 %d ||%c%c%c%c%c%c%c%c||           %d ||%c%c%c%c%c%c%c%c||\n",VEL_MAX , me[9], me[9], me[9], me[9], me[9], me[9], me[9], me[9], VEL_MAX, md[9], md[9], md[9], md[9], md[9], md[9], md[9], md[9]);
    for(i=8; i>0; i--){
         printf("                   ||%c%c%c%c%c%c%c%c||             ||%c%c%c%c%c%c%c%c||\n", me[i], me[i], me[i], me[i], me[i], me[i], me[i], me[i], md[i], md[i], md[i], md[i], md[i], md[i], md[i], md[i]);
    }
    printf("                -%d ||%c%c%c%c%c%c%c%c||          -%d ||%c%c%c%c%c%c%c%c||\n",VEL_MAX, me[0], me[0], me[0], me[0], me[0], me[0], me[0], me[0], VEL_MAX, md[0], md[0], md[0], md[0], md[0], md[0], md[0], md[0]);
}
